// we need to inject the dependency of ngRoute into our application.
var app = angular.module('app', ['ngRoute', 'ngSanitize', 'angularFileUpload', 'cgBusy']);
app
   .run(function ($templateCache) {
       $templateCache.put('custom-busy.html',
           "<div class=\"cssload-loader\"><div class=\"cssload-inner cssload-one\"></div><div class=\"cssload-inner cssload-two\"></div><div class=\"cssload-inner cssload-three\"></div></div>"
           );
   });
app.config(routesConfig);
routesConfig.$inject = ['$locationProvider', '$routeProvider'];
// the routing rules using the $routeProvidor
//GOALS::
//Single page application
//No page refresh on page change
//Different data on each page

function routesConfig($locationProvider, $routeProvider, $stateProvider) {
    //By default, Angular will throw a hash (#) into the URL
    //eg:http://localhost:11385/index.html#/products
    // We will be using $routeProvider in Angular to handle our routing. This way, Angular will handle all of the magic required to go get a new file and inject it into our layout.

    // The important thing to notice here is that I am also attaching the controller and  controller Alias with the route too.
    // This would mean that the specified controller will get associated with the specified view automatically and I don't have to put a ng-controller in the view itself.(eg:products controller)

    $locationProvider.html5Mode(false);

    $routeProvider.when('/products', {
        templateUrl: 'views/products.html',
        controller: 'ProductsController',
        controllerAs: 'vm'
    })
     .when('/topics', {
         templateUrl: 'views/topics.html'
     })
      .when('/databinding', {
          templateUrl: 'views/databinding.html'
      })
      .when('/myvalidations', {
          templateUrl: 'views/myvalidations.html',
          controller: 'validateCtrl',
          controllerAs: 'vm'
      })
     .when('/events', {
         templateUrl: 'views/events.html',
         controller: 'EventsController',
         controllerAs: 'events'
     })
     .when('/inventory', {
         templateUrl: 'views/inventory.html',
         controller: 'InventoryCtrl',
         controllerAs: 'inventory'
     })
      .when('/promises', {
          templateUrl: 'views/promises.html'
      })
      .when('/store', {
          templateUrl: 'views/store.htm',
          controller: 'StoreCtrl',
          controllerAs: 'store'
      })
         .when('/questiontemplate', {
             templateUrl: 'views/questiontemplate.html',
             controller: 'QuestionCtrl',
             controllerAs: 'questions'
         })
       .when('/shoppingCart', {
           templateUrl: 'views/shoppingCart.htm',
           controller: 'CartSummaryCtrl',
           controllerAs: 'cart'
       })

    .otherwise({ redirectTo: "topics" })//default Url
};