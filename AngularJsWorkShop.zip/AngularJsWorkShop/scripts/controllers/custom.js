/*
*  Products controller
*  In Angular we have the $q service that provide deferred and promise implementations. This $q service is heavily inspired by the Q library of Kris Kowal.
*  vm is used to represent the binding scope. This gets rid of the $scope variable from most of my controllers.
*/

(function () {
    angular
        .module('app')
        .controller("ProductsController", ProductsController);

    // We are injecting the $http,$q to the ProductsController
    ProductsController.$inject = ['$scope', '$http', '$q', 'myDataService'];
    function ProductsController($scope, $http, $q, myDataService) {
        var vm = this;
        var url = "/api/Products/GetProducts";
        vm.Productspromise = myDataService.GetPromise(url);
        vm.Productspromise.then(function (dataProducts) {
            vm.products = dataProducts;
        });
        vm.editing = false;
        //method to Add Product;
        vm.addProduct = function (item) {
            if (vm.ProductsForm.$valid) {
                //creating product object
                var product =
                    {
                        ProductId: vm.products.count + 1,
                        ProductName: vm.ProductName,
                        ProductCode: vm.ProductCode,
                        Price: vm.Price,
                        Quantity: vm.Quantity
                    };
                //inserting the product object into products array
                vm.products.push(product);
                var url = '/api/Products/SaveProducts';
                vm.Productspromise = myDataService.PostPromise(url, vm.products);
                vm.Productspromise.then(function (dataProducts) {
                    vm.product = {};
                });
            }
            else {
                vm.ProductsForm.ProductName.$dirty = true;
                vm.ProductsForm.ProductCode.$dirty = true;
                vm.ProductsForm.txtPrice.$dirty = true;
                vm.ProductsForm.txtQuantity.$dirty = true;
            }
        };
        //method to Remove Product;
        vm.removeProduct = function (index) {
            vm.products.splice(index, 1);
        }
        //Method to Edit Product
        vm.editProduct = function (index) {
            vm.editing = vm.products.indexOf(index);
        }
        vm.totalPrice = function () {
            var total = 0;
            if (vm.products != undefined) {
                for (count = 0; count < vm.products.length; count++) {
                    total += vm.products[count].Price * vm.products[count].Quantity;
                }
            }

            return total;
        }
        vm.saveField = function (index) {
            if (vm.editing !== false) {
                vm.editing = false;
            }
        };
        vm.cancel = function (index) {
            if (vm.editing !== false) {
                vm.editing = false;
            }
        };
    };
}());

/*
*  Events Controller
*/

(function () {
    angular
        .module('app')
        .controller("EventsController", EventsController);

    EventsController.$inject = ['$scope', '$http'];
    function EventsController($scope, $http) {
        var vm = this;
        vm.count = 0;
        vm.showMe = false;
        vm.ShowDiv = function () {
            vm.showMe = !vm.showMe;
        }
    };
}());

/*
*  Data binding controller
*/

(function () {
    angular
        .module('app')
        .controller("DataBindingController", DataBindingController);

    DataBindingController.$inject = ['$scope', '$http'];
    function DataBindingController($scope, $http) {
        var vm = this;
        vm.firstName = 'Sunil';
        vm.lastName = 'Thatipaka';
    };
}());

/*
*  validations controller
*/

(function () {
    angular
        .module('app')
        .controller("validateCtrl", validateCtrl);

    validateCtrl.$inject = ['$scope', '$http'];
    function validateCtrl($scope, $http) {
        var vm = this;

        vm.addProduct = function () {
            if (vm.ProductsForm.$valid) {
                //do something
            }
            else {
                vm.ProductsForm.ProductName.$dirty = true;
                vm.ProductsForm.ProductCode.$dirty = true;
                vm.ProductsForm.txtPrice.$dirty = true;
                vm.ProductsForm.txtQuantity.$dirty = true;
            }
        };
    };
}());

/*
*  Inventory controller
*/

(function () {
    angular
        .module('app')
        .controller("InventoryCtrl", InventoryCtrl);

    InventoryCtrl.$inject = ['$scope', '$http', '$q', 'myDataService'];
    function InventoryCtrl($scope, $http, $q, myDataService) {
        var vm = this;
        var url = "/api/Products/GetProducts";
        $scope.Productspromise = myDataService.GetPromise(url);
        $scope.Productspromise.then(function (dataProducts) {
            $scope.products = dataProducts;
            $scope.productscount = $scope.products.length;
        });
    };
}());

/*
*  inventory Products directive
*/

(function () {
    angular
        .module('app')
    .directive('inventoryProducts', function () {
        return {
            restrict: 'EA',              // directive is an Element and Attribute
            scope: {                     // set up directive's isolated scope
                productscount: "@",     //  productscount var passed by value (string, one-way)
                productsdata: '='       // productsdata var passed by reference (two-way)
            },
            controller: ['$scope', function ($scope) {
                var p = $scope;
            }],
            templateUrl: 'vendor/inventory-product/inventoryproduct.html',
            replace: true,          // replace original markup with template
            transclude: false,     // do not copy original HTML content
            link: function (scope, element) {
            }
        };
    });
}());

/*
*  Display Store controller
*/

(function () {
    angular
        .module('app')
        .controller("StoreCtrl", StoreCtrl);

    StoreCtrl.$inject = ['$scope', '$http', '$q', '$filter', '$location', 'myDataService'];
    function StoreCtrl($scope, $http, $q, $filter, $location, myDataService) {
        var vm = this;
        //get the products from Data Model
        var url = "../../dataModels/products.json";
        vm.storepromise = myDataService.GetPromise(url);
        vm.storepromise.then(function (dataProducts) {
            vm.products = dataProducts;
        });
        vm.AddedProducts = [];
        if (sessionStorage["Cart_items"] != null) {
            vm.AddedProducts = angular.fromJson(sessionStorage["Cart_items"]);
        }
        // adds an item to the cart
        vm.addItem = function (product, quantity) {
            vm.product = $filter('filter')(vm.AddedProducts, { ProductCode: product.ProductCode });
            if (vm.product.length > 0) {
                product.Quantity = product.Quantity + quantity;
            }
            else {
                vm.AddedProducts.push(product);
            }
        }
        //Method to calculate total price
        vm.getTotalPrice = function () {
            var total = 0;
            angular.forEach(vm.AddedProducts, function (item, key) {
                total += 1 * item.Price;
            });
            return total;
        }
        vm.getTotalCount = function () {
            var TotalCount = 0;
            TotalCount = vm.AddedProducts.length;
            return TotalCount;
        }
        vm.checkout = function () {
            //You can place data onto the sessionStorage object and that data persists for as long as that window (or tab) is open.
            //Even if you navigate away from the page that stored the data and then navigate back, the data saved to sessionStorage is still available.
            //Making things more interesting, sessionStorage is unique to a particular window or tab
            sessionStorage["Cart_items"] = angular.toJson(vm.AddedProducts);
            $location.path("/shoppingCart");
        }
        vm.Proceed = function () {
            $location.path("/store");
        };
    };
}());

/*
*  Display Cart Summary controller
*/

(function () {
    angular
        .module('app')
        .controller("CartSummaryCtrl", CartSummaryCtrl);

    CartSummaryCtrl.$inject = ['$scope', '$http', '$filter', '$location'];
    function CartSummaryCtrl($scope, $http, $filter, $location) {
        var vm = this;
        if (sessionStorage["Cart_items"] != undefined) {
            vm.items = angular.fromJson(sessionStorage["Cart_items"]);
        }
        vm.addItem = function (item, quantity, action) {
            vm.product = $filter('filter')(vm.items, { ProductCode: item.ProductCode });
            var updatedQty = 0;
            if (action == "add") {
                updatedQty = vm.product[0].Quantity + quantity;
            }
            else if (action == "remove") {
                updatedQty = vm.product[0].Quantity - quantity;
            }

            vm.product[0].Quantity = updatedQty;
        };

        vm.remove = function (item, index) {
            vm.items.splice(index, 1);
        };
        vm.backtostore = function () {
            $location.path("/store");
        };
        vm.getTotalPrice = function () {
            var total = 0;
            angular.forEach(vm.items, function (item, key) {
                total += (item.Quantity * item.Price);
            });
            return total;
        }
    };
}());

/*
*  Display Question  controller
*/

(function () {
    angular
        .module('app')
        .controller("QuestionCtrl", QuestionCtrl);

    QuestionCtrl.$inject = ['$scope', '$http', '$q', '$filter', '$location', 'myDataService'];
    function QuestionCtrl($scope, $http, $q, $filter, $location, myDataService) {
        var vm = this;
        var url = "../../dataModels/questionsModel.json";
        vm.Questionspromise = myDataService.GetPromise(url);
        vm.Questionspromise.then(function (dataQuestions) {
            vm.QuestionsList = dataQuestions;
            vm.FormName = "APPLICATION FORM";
            vm.FormCode = "AL007"
            vm.form = $scope.myForm.$data;
        });
        vm.SubmitFormData = function () {
            if (vm.EditForm.$valid) {
                var FormData =
                {
                    "FormName": vm.FormName,
                    "FormCode": vm.FormCode,
                    "Description": "",
                    "JSONString": angular.toJson($scope.myForm.$data)
                };

                var url = '/api/FormBuilder/SaveFormData';
                vm.Formspromise = myDataService.PostPromise(url, FormData);
                vm.Formspromise.then(function (dataProducts) {
                });
            }
            else {
                angular.forEach(vm.EditForm.$error, function (field) {
                    angular.forEach(field, function (errorField) {
                        errorField.$dirty = true;
                    })
                });
                //  alert("Please Enter all the mandatory fields")
            }
        };
    };
}());

/*
*  factory myDataService
*/

(function () {
    angular
        .module('app')
       .factory('myDataService', ['$http', '$q', function ($http, $q) {
           return {
               GetPromise: function (url) {
                   //  Deferred represents a task that will finish in the future. We can get a new deferred object by calling the defer() function on the $q service.
                   var defer = $q.defer();
                   $http.get(url).then(function (response) {
                       // The  method resolve is used to signal that the task has succeeded
                       // The method has one parameter. Whoever calls the method resolve can pass any type of information which shall be the result of the task.
                       // It can be a simple type like a string or a number or a complex object.
                       defer.resolve(response.data);
                   }, function (response) {
                       // The reject is used to signal that the task has failed. The reject method also takes one parameter, the reason of the failure.
                       // Again the parameter can be a simple type like a string or a complex type like an Error object.
                       defer.reject(response);
                   });
                   return defer.promise;
               },
               PostPromise: function (url, data) {
                   //  Deferred represents a task that will finish in the future. We can get a new deferred object by calling the defer() function on the $q service.
                   var defer = $q.defer();
                   $http.post(url, data).then(function (response) {
                       // The  method resolve is used to signal that the task has succeeded
                       // The method has one parameter. Whoever calls the method resolve can pass any type of information which shall be the result of the task.
                       // It can be a simple type like a string or a number or a complex object.
                       defer.resolve(response);
                   }, function (response) {
                       // The reject is used to signal that the task has failed. The reject method also takes one parameter, the reason of the failure.
                       // Again the parameter can be a simple type like a string or a complex type like an Error object.
                       defer.reject(response);
                   });
                   return defer.promise;
               }
           }
       }]);
}());